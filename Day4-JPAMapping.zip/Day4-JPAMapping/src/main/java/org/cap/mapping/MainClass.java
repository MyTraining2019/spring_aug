package org.cap.mapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager=
					factory.createEntityManager();
		
		
		EntityTransaction transaction=
				entityManager.getTransaction();
		
		transaction.begin();
			Customer  customer=new Customer("tom","jerry",34000);
			Address address=new Address(1001, "North car Street", "Chennai", customer);
			
			entityManager.persist(customer);
			entityManager.persist(address);
		
		
		transaction.commit();
		entityManager.close();
		factory.close();
		
		
	}

}
