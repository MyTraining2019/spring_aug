package org.cap.manytomany;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
				emf.createEntityManager();
		
		EntityTransaction entityTransaction=
				entityManager.getTransaction();
		
		
		Delegate delegate=new Delegate(1, "Tom");
		Delegate delegate1=new Delegate(2, "jack");
		Delegate delegate2=new Delegate(3, "Jessie");
		
		Event event=new Event(1001, "Java_101");
		Event event2=new Event(1002, "ORacle_101");
		
		delegate.getEvents().add(event2);
		delegate.getEvents().add(event);
		delegate1.getEvents().add(event2);
		delegate2.getEvents().add(event2);
		delegate2.getEvents().add(event);
		
		
		entityTransaction.begin();
			entityManager.persist(event);
			entityManager.persist(event2);
			entityManager.persist(delegate);
			entityManager.persist(delegate1);
			entityManager.persist(delegate2);
			
	
		
		entityTransaction.commit();
		
		entityManager.close();
		emf.close();
	}

}
