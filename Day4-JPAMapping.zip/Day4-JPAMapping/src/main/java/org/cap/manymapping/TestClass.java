package org.cap.manymapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager=
					factory.createEntityManager();
		
		
		EntityTransaction transaction=
				entityManager.getTransaction();
		
		Company company=new Company(1234, "Capgemini Pvt Ltd");
		Company company2=new Company(190, "TATA Consultancy");
		
		Employee employee=new Employee( "Tom", company2);
		Employee employee1=new Employee( "Jerry", company);
		Employee employee2=new Employee( "Jack", company);
		Employee employee3=new Employee( "Thompson", company);
		Employee employee4=new Employee( "Annie", company2);
		
		transaction.begin();
			entityManager.persist(company2);
			entityManager.persist(company);
			entityManager.persist(employee);
			entityManager.persist(employee1);
			entityManager.persist(employee2);
			entityManager.persist(employee3);
			entityManager.persist(employee4);
		
		transaction.commit();
		entityManager.close();
		factory.close();
		

	}

}
