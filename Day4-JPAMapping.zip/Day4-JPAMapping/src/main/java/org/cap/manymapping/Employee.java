package org.cap.manymapping;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int employeeId;
	private String empName;
	
	@ManyToOne
	@JoinColumn(name="company_fk")
	private Company company;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public Employee(int employeeId, String empName, Company company) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.company = company;
	}
	
	public Employee( String empName, Company company) {
		super();
		//this.employeeId = employeeId;
		this.empName = empName;
		this.company = company;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", empName=" + empName + ", company=" + company + "]";
	}

	
	
	
}
