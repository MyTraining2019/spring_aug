package org.cap.boot;

import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BootClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("myBeans.xml");
		
		Employee employee=(Employee)context.getBean("employee");
		System.out.println(employee);
		
		
		//context.close();
		context.registerShutdownHook();
	}

}
