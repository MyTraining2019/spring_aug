package org.cap.boot;

import org.cap.model.CollectionDemo;
import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("collectionDemo.xml");
		
		CollectionDemo demo=(CollectionDemo) context.getBean("collectDemo");
			System.out.println(demo.getNames());
			//System.out.println(demo.getEmployees());
			for(Employee employee:demo.getEmployees())
				System.out.println(employee);
			
			System.out.println(demo.getFruits());
		context.close();

	}

}
