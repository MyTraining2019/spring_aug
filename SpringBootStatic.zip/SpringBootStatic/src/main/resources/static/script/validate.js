function validateLogin(){
	var flag=false;
	var userName=logForm.userName.value;
	
	if(userName==null||userName==""){
		document.getElementById('userErrMsg').innerHTML="* Please enter userName";
	}else{
		flag=true;
	}
	
	
	return flag;
}