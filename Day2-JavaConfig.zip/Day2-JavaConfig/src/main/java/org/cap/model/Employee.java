package org.cap.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	
	@Autowired
	@Qualifier("caddress")
	private Address address;
	
	

	public Employee() {
		System.out.println("Employee no-arg Constructor");
	}
	public Employee(int employeeId, String firstName, String lastName, double salary) {
		super();
		System.out.println("Employee 5-arg Constructor");
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		//this.address = address;
	}
	

	public Employee(int employeeId, String firstName, String lastName, double salary, Address address) {
		super();
		System.out.println("Employee 5-arg Constructor");
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.address = address;
	}
	
	@PostConstruct
	public void init() {
		System.out.println("bean initialized.............");
	}
	
	@PreDestroy
	public void destroyed() {
		System.out.println("bean destoryed.............");
	}
	
	
	
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	
	
	public void setAddress(Address address) {
		System.out.println("Set Address.....");
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", address=" + address + "]";
	}
	
	

}
