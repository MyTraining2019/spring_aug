package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {

	
	
	  @Bean("jack") public Employee getEmployee() { Employee employee=new
	  Employee(); employee.setEmployeeId(1001); employee.setFirstName("Jack");
	  employee.setLastName("thomson"); employee.setSalary(34000);
	  employee.setAddress(getAddress()); return employee; }
	 
	 
	
	
	@Bean("tom")
	public Employee getEmployee1() {
		Employee employee=new Employee(1234,"Tom","Jerry",23000);
//		employee.setEmployeeId(13241);
//		employee.setFirstName("Tom");
//		employee.setLastName("Jerry");
//		employee.setSalary(12000);
		//employee.setAddress(getAddress());
		return employee;
	}
	
	
	@Bean("caddress")
	public Address getAddress() {
		Address address=new Address("23", "South Street", "Chennai");
		return address;
	}
	
	
	  @Bean("haddress") public Address getAddress1() { Address address=new
	  Address("789", "South Car Street", "Hyderabad"); return address; }
	 
	
	
	
	
	
	
	
}
