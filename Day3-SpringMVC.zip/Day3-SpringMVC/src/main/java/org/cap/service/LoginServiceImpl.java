package org.cap.service;

import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Override
	public boolean validateLogin(String userName, String userPassword) {
		if(userName.equals("tom") && 
				userPassword.equals("12345_FS"))
			return true;
		return false;
	}

}
