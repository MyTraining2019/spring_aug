package org.cap.service;

public interface ILoginService {
	public boolean validateLogin(String userName,String userPassword);
}
