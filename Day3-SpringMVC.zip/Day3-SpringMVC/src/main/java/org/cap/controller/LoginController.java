package org.cap.controller;

import org.cap.model.Registration;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	
	@PostMapping("/registerUser")
	public String registerNewUser(@ModelAttribute("registration")Registration registration) {
		System.out.println(registration);
		return "success";
	}
	
	@GetMapping("/register")
	public ModelAndView getRegistrationPage() {
		return new ModelAndView("register","registration",new Registration());
	}
	

	//@RequestMapping(value = "/validateLogin",method = RequestMethod.POST)
	@PostMapping("/validateLogin")
	public String validateUserLogin(
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd
			) {
		
		if(loginService.validateLogin(userName, userPwd)) {
			return "mainPage";
					
		}
		
		return "redirect:/";
	}
}
