package org.cap.model;

public class Address {
	private String addressLine;
	private String city;
	private String zipcode;
	private String country;
	public Address(String addressLine, String city, String zipcode, String country) {
		super();
		this.addressLine = addressLine;
		this.city = city;
		this.zipcode = zipcode;
		this.country = country;
	}
	public Address() {
		super();
		
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Address [address=" + addressLine + ", city=" + city + ", zipcode=" + zipcode + ", country=" + country + "]";
	}
	
	
	
}
