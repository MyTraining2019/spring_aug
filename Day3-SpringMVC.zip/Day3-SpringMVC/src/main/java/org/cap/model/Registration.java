package org.cap.model;

import java.time.LocalDate;

public class Registration {
	private int registrationId;
	private String firstName;
	private String lastName;
	private String password;
	private String confirmPassword;
	private LocalDate dateOfBirth;
	private String gender;
	private String email;
	private Address address;
	private String mobileNo;
	public Registration(int registrationId, String firstName, String lastName, String password, String confirmPassword,
			LocalDate dateOfBirth, String gender, String email, Address address, String mobileNo) {
		super();
		this.registrationId = registrationId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.mobileNo = mobileNo;
	}
	public Registration() {
		super();
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + ", dateOfBirth=" + dateOfBirth
				+ ", gender=" + gender + ", email=" + email + ", address=" + address + ", mobileNo=" + mobileNo + "]";
	}
	
	
	
}
