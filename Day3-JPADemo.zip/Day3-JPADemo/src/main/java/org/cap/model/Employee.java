package org.cap.model;

import java.time.LocalDate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="employee_details")
public class Employee {
	
	@Id
	@GeneratedValue
	private int employeeId;
	
	@Column(name="fName",length = 50,nullable = false)
	private String firstName;
	private String lastName;
	
	@Basic
	private double salary;
	
	@Column(unique = true)
	private String email;
	
	@Transient
	private String empPassword;
	
	private LocalDate dateOfBirth;

	public Employee(int employeeId, String firstName, String lastName, double salary, String email, String empPassword,
			LocalDate dateOfBirth) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.email = email;
		this.empPassword = empPassword;
		this.dateOfBirth = dateOfBirth;
	}
	
	public Employee( String firstName, String lastName, double salary, String email, String empPassword,
			LocalDate dateOfBirth) {
		super();
		//this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.email = email;
		this.empPassword = empPassword;
		this.dateOfBirth = dateOfBirth;
	}
	
	public Employee() {
		
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", email=" + email + ", empPassword=" + empPassword + ", dateOfBirth="
				+ dateOfBirth + "]";
	}
	


}
