package org.cap.boot;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Employee;

public class TestClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
				emf.createEntityManager();
		
		EntityTransaction transaction=
				entityManager.getTransaction();
		//new born enity object
		Employee employee=new Employee("Tom", "Jerry", 23000,"tom@gmail.com","tom123",LocalDate.of(1990, 3, 21));

		Employee jack=new Employee("Jack", "Smith", 535,"jack@gmail.com","tom123",LocalDate.of(1991, 3, 21));
		
		Employee annie=new Employee("Annie", "George", 23213,"annie@gmail.com","tom123",LocalDate.of(1989, 5, 1));
		
		transaction.begin();
		//managed state
			entityManager.persist(employee);
			entityManager.persist(jack);
			entityManager.persist(annie);
		
		transaction.commit();
		
		//detached State
		entityManager.close();
		
	}

}
