package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Employee;
import org.springframework.data.repository.query.Param;

public interface IEmployeeDBService {

	
	public List<Employee> getAllEmployeeData(double minSalary,double maxSalary);
	public List<Employee> getEmployees();

	public Employee findEmployee(Integer empId);

	public List<Employee> deleteEmployee(Integer empId);

	public List<Employee> createEmployee(Employee employee);

	public List<Employee> updateEmployee(Employee employee);
	public List<Employee> findBySalary(double salary);
	public List<Employee> getByFirstNameIgnoreCase(String firstName);
	public List<Employee> getByFirstNameIgnoreCaseAndLastNameIgnoreCase(String firstName,String lastName);
	public List<Employee> getByFirstNameAndLastNameAllIgnoreCase(String firstName,String lastName);
}
