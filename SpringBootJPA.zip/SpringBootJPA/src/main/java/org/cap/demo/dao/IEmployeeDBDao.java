package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("employeeDBDao")
@Transactional
public interface IEmployeeDBDao extends JpaRepository<Employee, Integer>{
	
	@Query("from Employee emp where emp.salary>:minSalary and emp.salary<:maxSalary")
	public List<Employee> getAllEmployeeData(@Param("minSalary")double minSalary, 
			@Param("maxSalary")double maxSalary);
	
	
	
	
	public List<Employee> findBySalary(double salary);
	public List<Employee> getByFirstNameIgnoreCase(String firstName);
	public List<Employee> getByFirstNameIgnoreCaseAndLastNameIgnoreCase(String firstName,String lastName);
	public List<Employee> getByFirstNameAndLastNameAllIgnoreCase(String firstName,String lastName);

}
