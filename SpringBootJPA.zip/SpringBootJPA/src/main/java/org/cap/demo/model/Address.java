package org.cap.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Address {
	
	@Id
	@GeneratedValue
	private int addressId;
	private String addressLine;
	private String city;
	private String pincode;
	
	
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Address(String addressLine, String city, String pincode) {
		super();
		this.addressLine = addressLine;
		this.city = city;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	
	
	
	public Address(int addressId, String addressLine, String city, String pincode) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.city = city;
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLine=" + addressLine + ", city=" + city + ", pincode="
				+ pincode + "]";
	}
	
	

}
