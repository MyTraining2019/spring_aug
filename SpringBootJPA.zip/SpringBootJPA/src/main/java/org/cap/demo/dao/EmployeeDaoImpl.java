package org.cap.demo.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao{
	
	private static List<Employee> employees=dummyDb();
	
	private static List<Employee> dummyDb(){
		List<Employee> employees=new ArrayList<Employee>();
		employees.add(new Employee(1001, "Tom", "jerry", 23000, LocalDate.of(2019, 3, 12),
					new Address("South car street", "Chennai", "435435")));
		employees.add(new Employee(1002, "Jack", "Thomson", 456546, LocalDate.of(2019, 5, 2),
				new Address("North car street", "Mumbai", "12323")));
		employees.add(new Employee(1003, "Annie", "George", 32432, LocalDate.of(2012,7, 23),
				new Address("South Avvenue", "Hyderabad", "567676")));
		employees.add(new Employee(1004, "Tim", "Lee", 65767, LocalDate.of(2018, 6, 1),
				new Address("River Road", "Chennai", "9980")));
	
		
		return employees;
	}
	

	@Override
	public List<Employee> getEmployees() {
		
		return employees;
	}


	@Override
	public Employee findEmployee(Integer empId) {
		for(Employee employee:employees) {
			if(empId==employee.getEmployeeId())
				return employee;
		}
		return null;
	}


	@Override
	public List<Employee> deleteEmployee(Integer empId) {
		Employee employee=findEmployee(empId);
		if(employee!=null) {
			employees.remove(findEmployee(empId));
			return employees;
		}
		return null;
	}


	@Override
	public List<Employee> createEmployee(Employee employee) {
		employees.add(employee);
		return employees;
	}


	@Override
	public List<Employee> updateEmployee(Employee employee) {
		boolean flag=false;
		ListIterator<Employee> iterator= employees.listIterator();
		while(iterator.hasNext()) {
			Employee emp=iterator.next();
			if(emp.getEmployeeId()==employee.getEmployeeId()) {
				flag=true;
				iterator.set(employee);
			}
		}
		
		if(flag)
			return employees;
		else
			return null;
	}

}






