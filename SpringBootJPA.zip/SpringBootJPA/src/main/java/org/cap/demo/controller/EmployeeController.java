package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class EmployeeController {
	
	@Autowired
	private IEmployeeDao employeeDao;
	
	
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(
			@RequestBody Employee employee){
		List<Employee> employees= employeeDao.createEmployee(employee);
		
		if(employees==null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@PutMapping("/employees")
	public ResponseEntity<List<Employee>> updateEmployee(
			@RequestBody Employee employee){
		List<Employee> employees= employeeDao.updateEmployee(employee);
		
		if(employees==null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee details not updated!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	@DeleteMapping("/employees/{empId}")
	public ResponseEntity<List<Employee>> deleteEmployee(
			@PathVariable("empId")Integer empId){
		List<Employee> employees= employeeDao.deleteEmployee(empId);
		if(employees==null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee ID not available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> employees= employeeDao.getEmployees();
		if(employees==null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employees Not available!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
	
	@GetMapping("/employees/{empId}")
	public ResponseEntity<Employee> findEmployee(
			@PathVariable("empId")Integer empId){
		Employee employee= employeeDao.findEmployee(empId);
		if(employee==null) {
			return new ResponseEntity("Sorry! Employee ID Not Found!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	
}
