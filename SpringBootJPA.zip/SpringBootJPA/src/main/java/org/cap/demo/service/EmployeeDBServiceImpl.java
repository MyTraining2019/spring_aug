package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IEmployeeDBDao;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeDBService")
public class EmployeeDBServiceImpl implements IEmployeeDBService{
	
	@Autowired
	private IEmployeeDBDao employeeDBDao;

	@Override
	public List<Employee> getEmployees() {
		
		return employeeDBDao.findAll();
	}

	@Override
	public Employee findEmployee(Integer empId) {
		
		return employeeDBDao.getOne(empId);
	}

	@Override
	public List<Employee> deleteEmployee(Integer empId) {
		employeeDBDao.deleteById(empId);
		return employeeDBDao.findAll();
	}

	@Override
	public List<Employee> createEmployee(Employee employee) {
		employeeDBDao.save(employee);
		return employeeDBDao.findAll();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		
		return createEmployee(employee);
	}

	@Override
	public List<Employee> findBySalary(double salary) {
		
		return employeeDBDao.findBySalary(salary);
	}

	@Override
	public List<Employee> getByFirstNameIgnoreCase(String firstName) {
		// TODO Auto-generated method stub
		return employeeDBDao.getByFirstNameIgnoreCase(firstName);
	}

	@Override
	public List<Employee> getByFirstNameIgnoreCaseAndLastNameIgnoreCase(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return employeeDBDao.getByFirstNameIgnoreCaseAndLastNameIgnoreCase(firstName, lastName);
	}

	@Override
	public List<Employee> getByFirstNameAndLastNameAllIgnoreCase(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return employeeDBDao.getByFirstNameAndLastNameAllIgnoreCase(firstName, lastName);
	}

	@Override
	public List<Employee> getAllEmployeeData(double minSalary, double maxSalary) {
		// TODO Auto-generated method stub
		return employeeDBDao.getAllEmployeeData(minSalary, maxSalary);
	}

}
