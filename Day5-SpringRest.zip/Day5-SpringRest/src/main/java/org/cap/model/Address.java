package org.cap.model;

public class Address {
	private String addressLine;
	private String city;
	private String pincode;
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Address(String addressLine, String city, String pincode) {
		super();
		this.addressLine = addressLine;
		this.city = city;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	@Override
	public String toString() {
		return "Address [addressLine=" + addressLine + ", city=" + city + ", pincode=" + pincode + "]";
	}
	
	

}
