package org.cap.dao;

import java.util.List;

import org.cap.model.Employee;

public interface IEmployeeDao {
	
	public List<Employee> getEmployees();

	public Employee findEmployee(Integer empId);

	public List<Employee> deleteEmployee(Integer empId);

	public List<Employee> createEmployee(Employee employee);

	public List<Employee> updateEmployee(Employee employee);

}
